<?php
$cats = get_the_category();
?>
<a class="card reveal" href="<?php the_permalink(); ?>">
	<div class="card-img"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'ip-card', array( 'loading' => 'lazy' ) ); } ?></div>
	<div class="card-body">
		<p class="meta"><?php echo $cats ? esc_html( $cats[0]->name ) . ' · ' : ''; ?><?php echo esc_html( get_the_date() ); ?></p>
		<h3><?php the_title(); ?></h3>
		<p><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
	</div>
</a>
