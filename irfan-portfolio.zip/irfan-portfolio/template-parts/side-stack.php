<?php
/** Left column of cards. Each card is the entry point to a page. */
$current  = ip_section();
$services = ip_services();
$brands   = get_posts( array( 'post_type' => 'brand', 'numberposts' => 3, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
$posts    = get_posts( array( 'post_type' => 'post', 'numberposts' => 3, 'ignore_sticky_posts' => true ) );
$blog_url = get_option( 'page_for_posts' ) ? get_permalink( (int) get_option( 'page_for_posts' ) ) : home_url( '/' );
$photo    = (int) ip_opt( 'about_photo' );
$is       = fn( string $key ): string => $current === $key ? ' is-active' : '';
?>
<aside class="stack" aria-label="Site sections">

	<section class="scard scard-about<?php echo esc_attr( $is( 'about' ) ); ?>">
		<a class="pill stretch" href="<?php echo esc_url( ip_url( 'about' ) ); ?>">About</a>
		<p class="scard-title"><?php echo esc_html( ip_opt( 'about_card' ) ); ?></p>
		<div class="scard-foot">
			<ul class="mini-brands">
				<?php foreach ( $brands as $brand ) : ?>
					<li><?php echo has_post_thumbnail( $brand ) ? get_the_post_thumbnail( $brand, 'thumbnail', array( 'alt' => esc_attr( get_the_title( $brand ) ) ) ) : esc_html( get_the_title( $brand ) ); // phpcs:ignore ?></li>
				<?php endforeach; ?>
			</ul>
			<span class="avatar"><?php echo $photo ? wp_get_attachment_image( $photo, 'thumbnail' ) : esc_html( mb_substr( ip_opt( 'name' ), 0, 1 ) . ( mb_substr( strrchr( ' ' . ip_opt( 'name' ), ' ' ), 1, 1 ) ) ); // phpcs:ignore ?></span>
		</div>
	</section>

	<section class="scard scard-list<?php echo esc_attr( $is( 'expertise' ) ); ?>">
		<div class="scard-head">
			<h2>Expertise</h2>
			<a class="pill stretch" href="<?php echo esc_url( ip_url( 'expertise' ) ); ?>">Services</a>
		</div>
		<ol class="rows">
			<?php foreach ( $services as $n => $service ) : ?>
				<li><a href="<?php echo esc_url( ip_url( 'expertise' ) . '#service-' . ( $n + 1 ) ); ?>"><span><?php echo esc_html( $service['title'] ); ?></span><i><?php echo esc_html( str_pad( (string) ( $n + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></i></a></li>
			<?php endforeach; ?>
		</ol>
	</section>

	<?php if ( $posts ) : ?>
	<section class="scard scard-news<?php echo esc_attr( $is( 'blog' ) ); ?>">
		<div class="scard-head">
			<h2>Insights</h2>
			<a class="pill stretch" href="<?php echo esc_url( $blog_url ); ?>">Blog</a>
		</div>
		<ul class="news">
			<?php foreach ( $posts as $p ) : $cats = get_the_category( $p->ID ); ?>
				<li>
					<a href="<?php echo esc_url( get_permalink( $p ) ); ?>">
						<span class="news-text">
							<small><?php echo $cats ? esc_html( $cats[0]->name ) : ''; ?></small>
							<strong><?php echo esc_html( get_the_title( $p ) ); ?></strong>
							<time><?php echo esc_html( get_the_date( '', $p ) ); ?></time>
						</span>
						<span class="news-img"><?php echo has_post_thumbnail( $p ) ? get_the_post_thumbnail( $p, 'thumbnail' ) : ''; // phpcs:ignore ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</section>
	<?php endif; ?>

	<section class="scard scard-contact<?php echo esc_attr( $is( 'contact' ) ); ?>">
		<a class="pill stretch" href="<?php echo esc_url( ip_url( 'contact' ) ); ?>">Contact</a>
		<h2>Let's build it <em>together</em></h2>
		<p><?php echo esc_html( ip_opt( 'email' ) ); ?></p>
		<span class="arrow-big"><?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></span>
	</section>

</aside>
