<?php get_header(); ?>
<?php while ( have_posts() ) : the_post();
	$tags    = array_filter( array_map( 'trim', explode( ',', (string) get_post_meta( get_the_ID(), '_cs_tags', true ) ) ) );
	$results = array_filter( array_map( 'trim', explode( "\n", (string) get_post_meta( get_the_ID(), '_cs_results', true ) ) ) );
?>
<article class="article">
	<header class="page-head">
		<div class="wrap narrow">
			<p class="eyebrow">Case study · <?php echo esc_html( get_post_meta( get_the_ID(), '_cs_year', true ) ); ?></p>
			<h1><?php the_title(); ?></h1>
			<?php if ( $tags ) : ?><ul class="tags"><?php foreach ( $tags as $tag ) : ?><li><?php echo esc_html( $tag ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		</div>
	</header>
	<div class="wrap narrow">
		<?php if ( $results ) : ?>
			<dl class="stats">
				<?php foreach ( $results as $line ) : [ $num, $label ] = array_pad( array_map( 'trim', explode( '|', $line, 2 ) ), 2, '' ); ?>
					<div><dt><?php echo esc_html( $num ); ?></dt><dd><?php echo esc_html( $label ); ?></dd></div>
				<?php endforeach; ?>
			</dl>
		<?php endif; ?>
		<?php if ( has_post_thumbnail() ) : ?><figure class="article-img"><?php the_post_thumbnail( 'large' ); ?></figure><?php endif; ?>
		<div class="prose"><?php the_content(); ?></div>
		<p><a class="btn-mono" href="<?php echo esc_url( ip_url( 'contact' ) ); ?>">Start a project <?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></a></p>
	</div>
</article>
<?php endwhile; ?>
<?php get_footer(); ?>
