<?php get_header(); ?>
<section class="page-head">
	<div class="wrap">
		<p class="eyebrow">404</p>
		<h1>That page doesn't exist.</h1>
		<p class="lead">It may have moved, or the link is wrong.</p>
		<a class="btn-mono" href="<?php echo esc_url( home_url( '/' ) ); ?>">Back to home <?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></a>
	</div>
</section>
<?php get_footer(); ?>
