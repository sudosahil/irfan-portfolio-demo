<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); $cats = get_the_category(); ?>
<article class="article">
	<header class="page-head">
		<div class="wrap narrow">
			<p class="eyebrow"><?php echo $cats ? esc_html( $cats[0]->name ) . ' · ' : ''; ?><?php echo esc_html( get_the_date() ); ?> · <?php echo esc_html( ip_reading_time() ); ?> min read</p>
			<h1><?php the_title(); ?></h1>
		</div>
	</header>
	<div class="wrap narrow">
		<?php if ( has_post_thumbnail() ) : ?><figure class="article-img"><?php the_post_thumbnail( 'large' ); ?></figure><?php endif; ?>
		<div class="prose"><?php the_content(); ?></div>
		<nav class="post-nav" aria-label="Posts">
			<?php previous_post_link( '%link', '← %title' ); ?>
			<?php next_post_link( '%link', '%title →' ); ?>
		</nav>
	</div>
</article>
<?php endwhile; ?>
<?php get_footer(); ?>
