<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); ?>
<article class="article">
	<header class="page-head"><div class="wrap narrow"><h1><?php the_title(); ?></h1></div></header>
	<div class="wrap narrow"><div class="prose"><?php the_content(); ?></div></div>
</article>
<?php endwhile; ?>
<?php get_footer(); ?>
