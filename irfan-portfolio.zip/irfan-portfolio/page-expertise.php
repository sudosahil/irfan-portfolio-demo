<?php
get_header();
$cases = new WP_Query( array( 'post_type' => 'case_study', 'posts_per_page' => 6, 'ignore_sticky_posts' => true ) );
?>
<article class="inner">
	<header class="page-head">
		<p class="eyebrow">Expertise</p>
		<h1 class="split"><?php echo ip_split_words( 'What I do.' ); // phpcs:ignore ?></h1>
	</header>

	<ol class="service-list">
		<?php foreach ( ip_services() as $n => $service ) : ?>
			<li class="service reveal" id="service-<?php echo esc_attr( (string) ( $n + 1 ) ); ?>">
				<span class="num"><?php echo esc_html( str_pad( (string) ( $n + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
				<h3><?php echo esc_html( $service['title'] ); ?></h3>
				<ul>
					<?php foreach ( $service['items'] as $item ) : ?><li><?php echo esc_html( $item ); ?></li><?php endforeach; ?>
				</ul>
			</li>
		<?php endforeach; ?>
	</ol>

	<?php if ( ip_opt( 'testimonial_quote' ) ) : ?>
		<blockquote class="quote reveal">
			<p>“<?php echo esc_html( ip_opt( 'testimonial_quote' ) ); ?>”</p>
			<footer><strong><?php echo esc_html( ip_opt( 'testimonial_author' ) ); ?></strong> <?php echo esc_html( ip_opt( 'testimonial_role' ) ); ?></footer>
		</blockquote>
	<?php endif; ?>

	<?php if ( $cases->have_posts() ) : ?>
		<h2 class="sub-label">Selected work</h2>
		<div class="cards">
			<?php while ( $cases->have_posts() ) : $cases->the_post(); ?>
				<a class="card reveal" href="<?php the_permalink(); ?>">
					<div class="card-img"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'ip-card', array( 'loading' => 'lazy' ) ); } ?></div>
					<div class="card-body">
						<h3><?php the_title(); ?> <small><?php echo esc_html( get_post_meta( get_the_ID(), '_cs_year', true ) ); ?></small></h3>
						<?php if ( $tags = get_post_meta( get_the_ID(), '_cs_tags', true ) ) : ?>
							<ul class="tags"><?php foreach ( array_filter( array_map( 'trim', explode( ',', $tags ) ) ) as $tag ) : ?><li><?php echo esc_html( $tag ); ?></li><?php endforeach; ?></ul>
						<?php endif; ?>
					</div>
				</a>
			<?php endwhile; wp_reset_postdata(); ?>
		</div>
	<?php endif; ?>

	<a class="btn-mono" href="<?php echo esc_url( ip_url( 'contact' ) ); ?>">Start a project <?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></a>
</article>
<?php get_footer(); ?>
