<?php get_header(); ?>
<?php
$photo  = (int) ip_opt( 'about_photo' );
$brands = get_posts( array( 'post_type' => 'brand', 'numberposts' => 12, 'orderby' => 'menu_order title', 'order' => 'ASC' ) );
?>
<article class="inner">
	<header class="page-head">
		<p class="eyebrow">About</p>
		<h1 class="split"><?php echo ip_split_words( "Hi, I'm " . ip_opt( 'name' ) . '.' ); // phpcs:ignore ?></h1>
	</header>

	<div class="about-top">
		<p class="statement reveal"><?php echo esc_html( ip_opt( 'about_text' ) ); ?></p>
		<?php if ( $photo ) : ?><figure class="portrait reveal"><?php echo wp_get_attachment_image( $photo, 'large' ); // phpcs:ignore ?></figure><?php endif; ?>
	</div>

	<div class="triplet">
		<?php foreach ( array( 'approach' => 'My Approach', 'impact' => 'My Impact', 'why' => 'Why work with me' ) as $key => $label ) : if ( ! ip_opt( $key ) ) { continue; } ?>
			<article class="reveal"><h3><?php echo esc_html( $label ); ?></h3><p><?php echo esc_html( ip_opt( $key ) ); ?></p></article>
		<?php endforeach; ?>
	</div>

	<dl class="stats reveal">
		<?php for ( $i = 1; $i <= 3; $i++ ) : if ( ! ip_opt( "stat_{$i}_num" ) ) { continue; } ?>
			<div><dt data-count><?php echo esc_html( ip_opt( "stat_{$i}_num" ) ); ?></dt><dd><?php echo esc_html( ip_opt( "stat_{$i}_label" ) ); ?></dd></div>
		<?php endfor; ?>
	</dl>

	<h2 class="sub-label">Experience</h2>
	<ul class="timeline">
		<li class="reveal"><span>Aug 2024 – Present</span><strong>Digital Head, Performance Marketing</strong><em>RB2F</em></li>
		<li class="reveal"><span>Dec 2022 – Jul 2024</span><strong>Senior Manager / Manager, Digital Marketing</strong><em>Yugen Consulting</em></li>
		<li class="reveal"><span>Apr 2021 – Jun 2022</span><strong>Digital Marketing Executive</strong><em>SocialStar.in</em></li>
		<li class="reveal"><span>Sep 2020 – Feb 2021</span><strong>Trainee Web Developer</strong><em>CareerTech IT Solutions</em></li>
	</ul>

	<h2 class="sub-label">Education</h2>
	<ul class="timeline">
		<li class="reveal"><span>2014 – 2019</span><strong>B.E. Mechanical Engineering</strong><em>Savitribai Phule Pune University</em></li>
	</ul>

	<?php if ( $brands ) : ?>
		<h2 class="sub-label">Brands I've worked with</h2>
		<ul class="logo-row reveal">
			<?php foreach ( $brands as $brand ) : ?>
				<li><?php echo has_post_thumbnail( $brand ) ? get_the_post_thumbnail( $brand, 'medium', array( 'alt' => esc_attr( get_the_title( $brand ) ), 'loading' => 'lazy' ) ) : '<span>' . esc_html( get_the_title( $brand ) ) . '</span>'; // phpcs:ignore ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php while ( have_posts() ) : the_post(); if ( trim( get_the_content() ) ) : ?><div class="prose"><?php the_content(); ?></div><?php endif; endwhile; ?>

	<a class="btn-mono" href="<?php echo esc_url( ip_url( 'contact' ) ); ?>"><?php echo esc_html( ip_opt( 'about_cta' ) ); ?> <?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></a>
</article>
<?php get_footer(); ?>
