	</main>

	<?php get_template_part( 'template-parts/side-stack' ); ?>

	<footer class="foot">
		<nav aria-label="Footer"><?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'fallback_cb' => false, 'depth' => 1 ) ); ?></nav>
		<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( ip_opt( 'name' ) ); ?>.<?php echo ip_opt( 'footer_note' ) ? ' ' . esc_html( ip_opt( 'footer_note' ) ) : ''; ?></p>
	</footer>
</div>

<div class="menu-overlay" id="menu-overlay" hidden>
	<nav aria-label="Primary">
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'depth' => 1 ) ); ?>
	</nav>
	<div class="overlay-foot">
		<?php if ( ip_opt( 'email' ) ) : ?><a href="mailto:<?php echo esc_attr( ip_opt( 'email' ) ); ?>"><?php echo esc_html( ip_opt( 'email' ) ); ?></a><?php endif; ?>
		<?php if ( ip_opt( 'phone' ) ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', ip_opt( 'phone' ) ) ); ?>"><?php echo esc_html( ip_opt( 'phone' ) ); ?></a><?php endif; ?>
	</div>
</div>

<?php wp_footer(); ?>
</body>
</html>
