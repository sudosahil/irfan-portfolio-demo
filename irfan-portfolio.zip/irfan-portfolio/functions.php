<?php
defined( 'ABSPATH' ) || exit;

define( 'IP_VERSION', '1.0.0' );

require_once __DIR__ . '/inc/helpers.php';
require_once __DIR__ . '/inc/customizer.php';
require_once __DIR__ . '/inc/post-types.php';
require_once __DIR__ . '/inc/contact-form.php';
require_once __DIR__ . '/inc/setup.php';

add_action( 'after_setup_theme', function (): void {
	load_theme_textdomain( 'irfan-portfolio', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo', array( 'height' => 60, 'width' => 200, 'flex-width' => true, 'flex-height' => true ) );
	add_image_size( 'ip-card', 800, 600, true );
	register_nav_menus( array( 'primary' => 'Primary menu', 'footer' => 'Footer menu' ) );
} );

add_action( 'wp_enqueue_scripts', function (): void {
	wp_enqueue_style( 'ip-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=DM+Mono:wght@400;500&family=Instrument+Serif:ital@0;1&display=swap', array(), null );
	wp_enqueue_style( 'ip-style', get_stylesheet_uri(), array( 'ip-fonts' ), IP_VERSION );
	wp_enqueue_script( 'ip-main', get_template_directory_uri() . '/assets/js/main.js', array(), IP_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
} );

add_action( 'wp_head', function (): void {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n" . '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}, 1 );

/** Person schema for SEO. */
add_action( 'wp_head', function (): void {
	if ( ! is_front_page() ) {
		return;
	}
	$same = array_values( array_filter( array( ip_opt( 'linkedin' ), ip_opt( 'instagram' ) ) ) );
	echo '<script type="application/ld+json">' . wp_json_encode( array(
		'@context' => 'https://schema.org',
		'@type'    => 'Person',
		'name'     => ip_opt( 'name' ),
		'jobTitle' => ip_opt( 'role' ),
		'url'      => home_url( '/' ),
		'email'    => ip_opt( 'email' ),
		'sameAs'   => $same,
	), JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 5 );

/** Blog excerpts: short and without the "[...]" suffix. */
add_filter( 'excerpt_length', fn(): int => 22 );
add_filter( 'excerpt_more', fn(): string => '…' );

/** Estimated reading time in minutes. */
function ip_reading_time( int $post_id = 0 ): int {
	return max( 1, (int) ceil( str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post_id ?: get_the_ID() ) ) ) / 220 ) );
}

/** Paginated links styled by the theme. */
function ip_pagination(): void {
	$links = paginate_links( array( 'type' => 'list', 'prev_text' => '← Prev', 'next_text' => 'Next →', 'mid_size' => 1 ) );
	if ( $links ) {
		echo '<nav class="pagination" aria-label="Pagination">' . $links . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput -- core-generated.
	}
}
