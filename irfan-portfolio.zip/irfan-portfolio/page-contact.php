<?php
get_header();
$services = ip_services();
$status   = sanitize_key( $_GET['contact'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification -- read-only status flag.
?>
<article class="inner">
	<header class="page-head">
		<p class="eyebrow">Contact</p>
		<h1 class="split"><?php echo ip_split_words( ip_opt( 'contact_title' ) ); // phpcs:ignore ?></h1>
		<p class="lead"><?php echo esc_html( ip_opt( 'contact_text' ) ); ?></p>
	</header>

	<div class="contact-grid">
		<ul class="contact-lines">
			<?php if ( ip_opt( 'email' ) ) : ?><li><small>Email</small><a href="mailto:<?php echo esc_attr( ip_opt( 'email' ) ); ?>"><?php echo esc_html( ip_opt( 'email' ) ); ?></a></li><?php endif; ?>
			<?php if ( ip_opt( 'phone' ) ) : ?><li><small>Phone</small><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', ip_opt( 'phone' ) ) ); ?>"><?php echo esc_html( ip_opt( 'phone' ) ); ?></a></li><?php endif; ?>
			<?php if ( ip_opt( 'whatsapp' ) ) : ?><li><small>WhatsApp</small><a href="https://wa.me/<?php echo esc_attr( preg_replace( '/\D/', '', ip_opt( 'whatsapp' ) ) ); ?>" target="_blank" rel="noopener">Message me</a></li><?php endif; ?>
			<?php if ( ip_opt( 'location' ) ) : ?><li><small>Based in</small><span><?php echo esc_html( ip_opt( 'location' ) ); ?></span></li><?php endif; ?>
		</ul>

		<form class="form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php if ( 'sent' === $status ) : ?>
				<p class="notice ok" role="status">Thanks! Your message is in. I'll get back to you soon.</p>
			<?php elseif ( 'invalid' === $status ) : ?>
				<p class="notice err" role="alert">Please fill in your name, a valid email and a message.</p>
			<?php elseif ( 'error' === $status ) : ?>
				<p class="notice err" role="alert">Something went wrong. Please try again, or email me directly.</p>
			<?php endif; ?>

			<input type="hidden" name="action" value="ip_contact">
			<?php wp_nonce_field( 'ip_contact', 'ip_contact_nonce' ); ?>
			<p class="hp" aria-hidden="true"><label>Leave empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>

			<div class="field"><label for="f-name">Name</label><input id="f-name" name="name" type="text" required autocomplete="name"></div>
			<div class="field-row">
				<div class="field"><label for="f-email">Email</label><input id="f-email" name="email" type="email" required autocomplete="email"></div>
				<div class="field"><label for="f-phone">Phone <small>(optional)</small></label><input id="f-phone" name="phone" type="tel" autocomplete="tel"></div>
			</div>

			<fieldset class="chips">
				<legend>What do you need?</legend>
				<?php foreach ( $services as $service ) : ?>
					<label><input type="checkbox" name="services[]" value="<?php echo esc_attr( $service['title'] ); ?>"><span><?php echo esc_html( $service['title'] ); ?></span></label>
				<?php endforeach; ?>
			</fieldset>

			<fieldset class="chips">
				<legend>Monthly budget</legend>
				<?php foreach ( ip_budgets() as $budget ) : ?>
					<label><input type="radio" name="budget" value="<?php echo esc_attr( $budget ); ?>"><span><?php echo esc_html( $budget ); ?></span></label>
				<?php endforeach; ?>
			</fieldset>

			<div class="field"><label for="f-msg">Tell me about your project</label><textarea id="f-msg" name="message" rows="5" required></textarea></div>
			<button class="btn-mono" type="submit">Send message <?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></button>
		</form>
	</div>
</article>
<?php get_footer(); ?>
