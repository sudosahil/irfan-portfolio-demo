<?php
defined( 'ABSPATH' ) || exit;

add_action( 'init', function (): void {
	register_post_type( 'case_study', array(
		'labels'       => array( 'name' => 'Case Studies', 'singular_name' => 'Case Study', 'add_new_item' => 'Add Case Study', 'edit_item' => 'Edit Case Study' ),
		'public'       => true,
		'has_archive'  => false,
		'menu_icon'    => 'dashicons-portfolio',
		'menu_position' => 5,
		'rewrite'      => array( 'slug' => 'work' ),
		'show_in_rest' => true,
		'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
	) );

	register_post_type( 'brand', array(
		'labels'       => array( 'name' => 'Brand Logos', 'singular_name' => 'Brand Logo', 'add_new_item' => 'Add Brand Logo', 'edit_item' => 'Edit Brand Logo' ),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-awards',
		'menu_position' => 6,
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
	) );

	register_post_type( 'enquiry', array(
		'labels'       => array( 'name' => 'Enquiries', 'singular_name' => 'Enquiry' ),
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-email-alt',
		'menu_position' => 7,
		'capability_type' => 'post',
		'capabilities' => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap' => true,
		'supports'     => array( 'title', 'editor' ),
	) );

	register_post_meta( 'case_study', '_cs_year', array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_text_field', 'auth_callback' => fn() => current_user_can( 'edit_posts' ) ) );
	register_post_meta( 'case_study', '_cs_tags', array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_text_field', 'auth_callback' => fn() => current_user_can( 'edit_posts' ) ) );
	register_post_meta( 'case_study', '_cs_results', array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_textarea_field', 'auth_callback' => fn() => current_user_can( 'edit_posts' ) ) );
} );

/* Case study details box (year, tags, result numbers). */
add_action( 'add_meta_boxes', function (): void {
	add_meta_box( 'cs_details', 'Case study details', function ( WP_Post $post ): void {
		wp_nonce_field( 'cs_details', 'cs_details_nonce' );
		printf( '<p><label><strong>Year</strong><br><input type="text" name="_cs_year" value="%s" class="widefat" placeholder="2025"></label></p>', esc_attr( (string) get_post_meta( $post->ID, '_cs_year', true ) ) );
		printf( '<p><label><strong>Tags</strong> (comma separated)<br><input type="text" name="_cs_tags" value="%s" class="widefat" placeholder="Meta Ads, Google Ads, CRO"></label></p>', esc_attr( (string) get_post_meta( $post->ID, '_cs_tags', true ) ) );
		printf( '<p><label><strong>Results</strong> (one per line, format: <code>number | label</code>)<br><textarea name="_cs_results" rows="4" class="widefat" placeholder="4.2x | ROAS&#10;-38% | CPA">%s</textarea></label></p>', esc_textarea( (string) get_post_meta( $post->ID, '_cs_results', true ) ) );
	}, 'case_study', 'normal', 'high' );
} );

add_action( 'save_post_case_study', function ( int $post_id ): void {
	if ( ! isset( $_POST['cs_details_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['cs_details_nonce'] ), 'cs_details' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	update_post_meta( $post_id, '_cs_year', sanitize_text_field( wp_unslash( $_POST['_cs_year'] ?? '' ) ) );
	update_post_meta( $post_id, '_cs_tags', sanitize_text_field( wp_unslash( $_POST['_cs_tags'] ?? '' ) ) );
	update_post_meta( $post_id, '_cs_results', sanitize_textarea_field( wp_unslash( $_POST['_cs_results'] ?? '' ) ) );
} );

/** Enquiry list: show who sent it and when. */
add_filter( 'manage_enquiry_posts_columns', fn( array $cols ): array => array( 'cb' => $cols['cb'], 'title' => 'Subject', 'ip_from' => 'From', 'date' => $cols['date'] ) );
add_action( 'manage_enquiry_posts_custom_column', function ( string $col, int $post_id ): void {
	if ( 'ip_from' === $col ) {
		echo esc_html( get_post_meta( $post_id, '_enq_email', true ) );
	}
}, 10, 2 );
