<?php
defined( 'ABSPATH' ) || exit;

/** Budget options are shown in the form; keep this list the single source of truth. */
function ip_budgets(): array {
	return array( 'Under ₹1L / month', '₹1L – ₹5L / month', '₹5L – ₹15L / month', '₹15L+ / month', 'Not sure yet' );
}

add_action( 'admin_post_nopriv_ip_contact', 'ip_handle_contact' );
add_action( 'admin_post_ip_contact', 'ip_handle_contact' );

function ip_handle_contact(): void {
	$back = function ( string $status ): void {
		wp_safe_redirect( add_query_arg( 'contact', $status, ip_url( 'contact' ) ) );
		exit;
	};

	if ( ! isset( $_POST['ip_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['ip_contact_nonce'] ), 'ip_contact' ) ) {
		$back( 'error' );
	}
	// Honeypot: real visitors never fill this.
	if ( ! empty( $_POST['website'] ) ) {
		$back( 'sent' );
	}

	$ip_key = 'ip_contact_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' );
	if ( get_transient( $ip_key ) ) {
		$back( 'error' );
	}

	$name    = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$phone   = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) );
	$budget  = sanitize_text_field( wp_unslash( $_POST['budget'] ?? '' ) );
	$budget  = in_array( $budget, ip_budgets(), true ) ? $budget : '';

	$allowed  = wp_list_pluck( ip_services(), 'title' );
	$selected = array_values( array_intersect( $allowed, array_map( 'sanitize_text_field', wp_unslash( (array) ( $_POST['services'] ?? array() ) ) ) ) );

	if ( '' === $name || ! is_email( $email ) || '' === $message ) {
		$back( 'invalid' );
	}

	$body = "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\nServices: " . implode( ', ', $selected ) . "\nBudget: {$budget}\n\n{$message}";

	// Stored in the dashboard first so an enquiry is never lost if mail delivery fails.
	$post_id = wp_insert_post( array(
		'post_type'    => 'enquiry',
		'post_status'  => 'private',
		'post_title'   => "{$name}: " . wp_trim_words( $message, 8 ),
		'post_content' => $body,
	) );
	if ( $post_id && ! is_wp_error( $post_id ) ) {
		update_post_meta( $post_id, '_enq_email', $email );
	}

	$sent = wp_mail(
		ip_opt( 'email' ) ?: get_option( 'admin_email' ),
		'New enquiry from ' . $name,
		$body,
		array( 'Reply-To: ' . $name . ' <' . $email . '>' )
	);

	set_transient( $ip_key, 1, 30 );
	$back( $sent || $post_id ? 'sent' : 'error' );
}
