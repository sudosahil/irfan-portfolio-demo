<?php
defined( 'ABSPATH' ) || exit;

/** Default content, taken from Irfan's LinkedIn profile. Every value is editable in Appearance > Customize. */
function ip_defaults(): array {
	return array(
		'name'         => 'Irfan Shaikh',
		'role'         => 'Digital Head, Performance Marketing',
		'location'     => 'Pune, Maharashtra, India',
		'status'       => 'Available for new projects',
		'hero_title'   => 'Scaling Ecommerce Brands',
		'hero_text'    => 'Your growth partner for paid media, CRO and data-driven strategy across Google, Meta and programmatic.',
		'hero_cta'     => 'Get in touch',
		'about_card'   => 'Driving profitable growth for ecommerce brands.',
		'about_photo'  => '',
		'stat_1_num'   => '90+',
		'stat_1_label' => 'Brands partnered with',
		'stat_2_num'   => '$5M+',
		'stat_2_label' => 'Ad spend managed',
		'stat_3_num'   => '₹3Cr',
		'stat_3_label' => 'Monthly ad spend handled',
		'about_text'   => "I'm the Digital Head at RB2F, where I lead performance marketing, GTM strategy, SEO and website development. My focus is sustainable e-commerce growth with outcomes you can measure.",
		'approach'     => 'Audience, creative and funnel decisions backed by analytics, not guesswork. Every campaign starts with the numbers.',
		'impact'       => 'Lower CPA, stronger ROAS and higher conversion rates across paid media, email and the website itself.',
		'why'          => 'One owner for the whole funnel: paid media, SEO, site and GTM working together instead of in silos.',
		'about_cta'    => 'Book a call',
		'email'        => 'irfanss549@gmail.com',
		'phone'        => '+91 7507664244',
		'whatsapp'     => '917507664244',
		'linkedin'     => 'https://www.linkedin.com/in/irfanshaikh096',
		'instagram'    => '',
		'service_1_title' => 'Performance Marketing',
		'service_1_items' => "Google Ads & PPC\nMeta (Facebook, Instagram) Ads\nProgrammatic advertising\nMarketplace ads (Amazon, Flipkart)",
		'service_2_title' => 'Conversion Optimization',
		'service_2_items' => "CRO audits & testing\nLanding page optimization\nBounce rate reduction\nHeatmaps & user behaviour (Hotjar)",
		'service_3_title' => 'Brand Growth & GTM',
		'service_3_items' => "Go-to-market strategy\nBrand analysis\nNew market expansion\nScalable growth frameworks",
		'service_4_title' => 'Websites & Ecommerce',
		'service_4_items' => "Shopify\nWordPress\nAdobe Commerce\nSEO & technical audits",
		'service_5_title' => 'Email, CRM & Analytics',
		'service_5_items' => "Email marketing (Mailchimp)\nPush notifications & segments\nGA, Search Console & UTM tracking\nC-PaaS integration",
		'testimonial_quote'  => '',
		'testimonial_author' => '',
		'testimonial_role'   => '',
		'contact_title' => "Let's build it together",
		'contact_text'  => 'Tell me about your brand and what you want to grow. I reply within one working day.',
		'footer_note'   => '',
	);
}

function ip_opt( string $key ): string {
	$defaults = ip_defaults();
	return (string) get_theme_mod( $key, $defaults[ $key ] ?? '' );
}

/** Services as [ ['title' => ..., 'items' => [...]], ... ] skipping empty ones. */
function ip_services(): array {
	$out = array();
	for ( $i = 1; $i <= 5; $i++ ) {
		$title = ip_opt( "service_{$i}_title" );
		if ( '' === $title ) {
			continue;
		}
		$items = array_filter( array_map( 'trim', explode( "\n", ip_opt( "service_{$i}_items" ) ) ) );
		$out[] = array( 'title' => $title, 'items' => $items );
	}
	return $out;
}

function ip_icon( string $name ): string {
	$paths = array(
		'mail'      => '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
		'linkedin'  => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
		'instagram' => '<rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>',
		'whatsapp'  => '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
		'arrow'     => '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
	);
	return '<svg class="ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $paths[ $name ] ?? '' ) . '</svg>';
}

/** Social/contact links shown in the header overlay and footer. */
function ip_socials(): array {
	$links = array();
	if ( ip_opt( 'instagram' ) ) {
		$links['instagram'] = array( ip_opt( 'instagram' ), 'Instagram' );
	}
	if ( ip_opt( 'linkedin' ) ) {
		$links['linkedin'] = array( ip_opt( 'linkedin' ), 'LinkedIn' );
	}
	if ( ip_opt( 'whatsapp' ) ) {
		$links['whatsapp'] = array( 'https://wa.me/' . preg_replace( '/\D/', '', ip_opt( 'whatsapp' ) ), 'WhatsApp' );
	}
	if ( ip_opt( 'email' ) ) {
		$links['mail'] = array( 'mailto:' . ip_opt( 'email' ), 'Email' );
	}
	return $links;
}

function ip_render_socials(): void {
	echo '<ul class="socials">';
	foreach ( ip_socials() as $icon => $link ) {
		printf(
			'<li><a href="%s" aria-label="%s"%s>%s</a></li>',
			esc_url( $link[0] ),
			esc_attr( $link[1] ),
			str_starts_with( $link[0], 'http' ) ? ' target="_blank" rel="noopener"' : '',
			ip_icon( $icon ) // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG.
		);
	}
	echo '</ul>';
}

/** Permalink for one of the theme pages, e.g. ip_url('contact') */
function ip_url( string $slug ): string {
	return home_url( '/' . $slug . '/' );
}

/** Which side card is "current" for the page being viewed. */
function ip_section(): string {
	if ( is_page( 'about' ) ) {
		return 'about';
	}
	if ( is_page( 'expertise' ) || is_singular( 'case_study' ) ) {
		return 'expertise';
	}
	if ( is_page( 'contact' ) ) {
		return 'contact';
	}
	if ( is_home() || is_singular( 'post' ) || is_category() || is_search() ) {
		return 'blog';
	}
	return '';
}

/** Headline split into words so CSS can reveal them one by one. */
function ip_split_words( string $text ): string {
	$out = '';
	foreach ( preg_split( '/\s+/', trim( $text ) ) as $i => $word ) {
		$out .= sprintf( '<span class="w"><span style="--i:%d">%s</span></span> ', $i, esc_html( $word ) );
	}
	return $out;
}
