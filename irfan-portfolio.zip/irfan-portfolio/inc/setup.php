<?php
defined( 'ABSPATH' ) || exit;

/**
 * On first activation: create the pages, set the static front page / posts page,
 * and build the menus, so the site matches the reference structure with no manual setup.
 */
add_action( 'after_switch_theme', function (): void {
	if ( get_option( 'ip_setup_v2' ) ) {
		return;
	}

	$make = function ( string $title, string $slug, string $content = '' ): int {
		$existing = get_page_by_path( $slug );
		if ( $existing ) {
			return $existing->ID;
		}
		return (int) wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content ) );
	};

	$home    = $make( 'Home', 'home' );
	$about   = $make( 'About', 'about' );
	$expert  = $make( 'Expertise', 'expertise' );
	$contact = $make( 'Contact', 'contact' );
	$blog    = $make( 'Blog', 'blog' );
	$privacy = $make( 'Privacy Policy', 'privacy-policy', ip_legal_text( 'privacy' ) );
	$terms   = $make( 'Terms of Service', 'terms-of-service', ip_legal_text( 'terms' ) );
	$refund  = $make( 'Refund Policy', 'refund-policy', ip_legal_text( 'refund' ) );

	// Pages like /about/ and /contact/ need pretty permalinks.
	if ( ! get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
	}

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home );
	update_option( 'page_for_posts', $blog );
	update_option( 'wp_page_for_privacy_policy', $privacy );

	$menus = array(
		'Primary' => array(
			'locations' => 'primary',
			'items'     => array( 'About' => get_permalink( $about ), 'Expertise' => get_permalink( $expert ), 'Blogs' => get_permalink( $blog ), 'Contact' => get_permalink( $contact ) ),
		),
		'Footer'  => array(
			'locations' => 'footer',
			'items'     => array( 'Privacy Policy' => get_permalink( $privacy ), 'Terms of Service' => get_permalink( $terms ), 'Refund Policy' => get_permalink( $refund ), 'Contact Details' => get_permalink( $contact ) ),
		),
	);

	$locations = get_theme_mod( 'nav_menu_locations', array() );
	foreach ( $menus as $name => $menu ) {
		if ( $old = wp_get_nav_menu_object( $name ) ) {
			wp_delete_nav_menu( $old->term_id );
		}
		$menu_id = wp_create_nav_menu( $name );
		if ( is_wp_error( $menu_id ) ) {
			continue;
		}
		foreach ( $menu['items'] as $label => $url ) {
			wp_update_nav_menu_item( $menu_id, 0, array( 'menu-item-title' => $label, 'menu-item-url' => $url, 'menu-item-status' => 'publish', 'menu-item-type' => 'custom' ) );
		}
		$locations[ $menu['locations'] ] = $menu_id;
	}
	set_theme_mod( 'nav_menu_locations', $locations );

	update_option( 'ip_setup_v2', 1 );
	flush_rewrite_rules();
} );

/** Starter legal copy. A lawyer should review before launch. */
function ip_legal_text( string $type ): string {
	$name = 'Irfan Shaikh';
	$text = array(
		'privacy' => "<h2>Information we collect</h2><p>When you use the contact form on this site, we collect the name, email address, phone number and message you provide. We use it only to reply to your enquiry.</p><h2>Analytics and cookies</h2><p>This site may use analytics and cookies to understand how visitors use it. You can disable cookies in your browser settings.</p><h2>Sharing</h2><p>We do not sell your personal information. We may share it with service providers who help operate this website, such as hosting and email.</p><h2>Your rights</h2><p>You can ask us to access, correct or delete the information we hold about you by emailing us.</p><h2>Contact</h2><p>Questions about this policy? Get in touch through the contact section of this site.</p>",
		'terms'   => "<h2>Using this website</h2><p>The content on this website is provided by {$name} for general information. By using the site you agree to these terms.</p><h2>Services</h2><p>Services are provided under a separate written agreement or proposal. Nothing on this website is a guarantee of specific results.</p><h2>Intellectual property</h2><p>All content, case studies and branding on this site belong to {$name} or the respective brand owners and may not be reused without permission.</p><h2>Liability</h2><p>To the extent permitted by law, we are not liable for losses arising from use of this website.</p><h2>Changes</h2><p>We may update these terms from time to time. Continued use of the site means you accept the updated terms.</p>",
		'refund'  => "<h2>Refund policy</h2><p>Consulting and management fees are agreed in writing before work begins. Fees for work already delivered are non-refundable.</p><h2>Advertising spend</h2><p>Ad spend paid directly to platforms such as Google or Meta is non-refundable and subject to those platforms' own policies.</p><h2>Disputes</h2><p>If you are unhappy with a deliverable, contact us within 7 days and we will work with you to resolve it.</p>",
	);
	return $text[ $type ] ?? '';
}
