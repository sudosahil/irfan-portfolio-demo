<?php
defined( 'ABSPATH' ) || exit;

add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ): void {
	$defaults = ip_defaults();

	$sections = array(
		'ip_hero'    => array( 'Home: Hero', array(
			'name' => 'Your name', 'role' => 'Role / job title', 'status' => 'Availability text',
			'hero_title' => 'Headline', 'hero_text' => array( 'Intro paragraph', 'textarea' ), 'hero_cta' => 'Button label',
			'stat_1_num' => 'Stat 1 number', 'stat_1_label' => 'Stat 1 label',
			'stat_2_num' => 'Stat 2 number', 'stat_2_label' => 'Stat 2 label',
			'stat_3_num' => 'Stat 3 number', 'stat_3_label' => 'Stat 3 label',
		) ),
		'ip_about'   => array( 'Home: About', array(
			'about_card' => array( 'Short line shown on the Home About card', 'textarea' ),
			'about_text' => array( 'About page paragraph', 'textarea' ),
			'approach' => array( 'My Approach', 'textarea' ), 'impact' => array( 'My Impact', 'textarea' ),
			'why' => array( 'Why work with me', 'textarea' ), 'about_cta' => 'Button label',
		) ),
		'ip_services' => array( 'Home: Expertise', array() ),
		'ip_testimonial' => array( 'Home: Testimonial (hidden until filled)', array(
			'testimonial_quote' => array( 'Quote', 'textarea' ), 'testimonial_author' => 'Author name', 'testimonial_role' => 'Author role / company',
		) ),
		'ip_contact' => array( 'Contact & Social', array(
			'contact_title' => 'Contact heading', 'contact_text' => array( 'Contact intro', 'textarea' ),
			'email' => array( 'Email (enquiries are sent here)', 'text', 'sanitize_email' ), 'phone' => 'Phone',
			'whatsapp' => 'WhatsApp number (digits with country code)', 'location' => 'Location',
			'linkedin' => array( 'LinkedIn URL', 'text', 'esc_url_raw' ), 'instagram' => array( 'Instagram URL', 'text', 'esc_url_raw' ),
			'footer_note' => 'Extra footer text',
		) ),
	);

	// Service fields: title + one item per line, five blocks.
	for ( $i = 1; $i <= 5; $i++ ) {
		$sections['ip_services'][1][ "service_{$i}_title" ] = "Service {$i} title";
		$sections['ip_services'][1][ "service_{$i}_items" ] = array( "Service {$i} items (one per line)", 'textarea' );
	}

	$priority = 30;
	foreach ( $sections as $section_id => $section ) {
		$wp_customize->add_section( $section_id, array( 'title' => $section[0], 'priority' => $priority++ ) );
		foreach ( $section[1] as $key => $field ) {
			$field = (array) $field;
			$type  = $field[1] ?? 'text';
			$wp_customize->add_setting( $key, array(
				'default'           => $defaults[ $key ] ?? '',
				'sanitize_callback' => $field[2] ?? ( 'textarea' === $type ? 'sanitize_textarea_field' : 'sanitize_text_field' ),
			) );
			$wp_customize->add_control( $key, array( 'label' => $field[0], 'section' => $section_id, 'type' => $type ) );
		}
	}

	// Photo shown on the Home About card and About page.
	$wp_customize->add_setting( 'about_photo', array( 'default' => '', 'sanitize_callback' => 'absint' ) );
	$wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'about_photo', array( 'label' => 'Your photo', 'section' => 'ip_about', 'mime_type' => 'image' ) ) );
} );
