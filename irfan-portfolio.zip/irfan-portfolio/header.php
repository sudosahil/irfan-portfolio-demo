<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>

<div class="app <?php echo is_front_page() ? 'is-home' : 'is-inner'; ?>">

	<header class="brand-card">
		<div class="brand-row">
			<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php if ( has_custom_logo() ) : the_custom_logo(); else : echo esc_html( ip_opt( 'name' ) ); endif; ?>
			</a>
			<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="menu-overlay">
				<span class="sr-only">Menu</span><span class="bars" aria-hidden="true"></span>
			</button>
		</div>
		<div class="brand-foot">
			<p class="dateline"><span data-date></span><br><?php echo esc_html( ip_opt( 'status' ) ); ?></p>
			<?php ip_render_socials(); ?>
		</div>
	</header>

	<main class="panel" id="main">
