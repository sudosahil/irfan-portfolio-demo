<?php
/** Blog listing (set as the Posts page), category and search archives. */
get_header();
$categories = get_categories( array( 'hide_empty' => true ) );
?>
<section class="page-head">
	<div class="wrap">
		<p class="eyebrow">Insights</p>
		<h1><?php echo is_category() ? esc_html( single_cat_title( '', false ) ) : ( is_search() ? 'Search: ' . esc_html( get_search_query() ) : 'Blog' ); ?></h1>
		<?php if ( count( $categories ) > 1 ) : ?>
			<ul class="pills">
				<li><a href="<?php echo esc_url( get_permalink( (int) get_option( 'page_for_posts' ) ) ?: home_url( '/' ) ); ?>"<?php echo is_home() ? ' aria-current="true"' : ''; ?>>All</a></li>
				<?php foreach ( $categories as $cat ) : ?>
					<li><a href="<?php echo esc_url( get_category_link( $cat ) ); ?>"<?php echo is_category( $cat->term_id ) ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $cat->name ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>

<section class="insights">
	<div class="wrap">
		<?php if ( have_posts() ) : ?>
			<div class="cards">
				<?php while ( have_posts() ) : the_post(); get_template_part( 'template-parts/post-card' ); endwhile; ?>
			</div>
			<?php ip_pagination(); ?>
		<?php else : ?>
			<p class="empty">No articles yet. Check back soon.</p>
		<?php endif; ?>
	</div>
</section>
<?php get_footer(); ?>
