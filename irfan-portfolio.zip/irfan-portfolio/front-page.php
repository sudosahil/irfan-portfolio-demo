<?php get_header(); ?>

<section class="hero" data-spotlight>
	<div class="blobs" aria-hidden="true"><i></i><i></i><i></i></div>
	<div class="grain" aria-hidden="true"></div>

	<div class="hero-top"><p class="hero-tag"><?php echo esc_html( ip_opt( 'role' ) ); ?></p><p class="hero-tag"><?php echo esc_html( ip_opt( 'location' ) ); ?></p></div>
	<h1 class="hero-title"><?php echo ip_split_words( ip_opt( 'hero_title' ) ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped per word. ?></h1>

	<div class="hero-bottom">
		<div>
			<p class="hero-text"><?php echo esc_html( ip_opt( 'hero_text' ) ); ?></p>
			<a class="btn-mono" href="<?php echo esc_url( ip_url( 'contact' ) ); ?>"><?php echo esc_html( ip_opt( 'hero_cta' ) ); ?> <?php echo ip_icon( 'arrow' ); // phpcs:ignore ?></a>
		</div>
		<ul class="hero-stats">
			<?php for ( $i = 1; $i <= 3; $i++ ) : if ( ! ip_opt( "stat_{$i}_num" ) ) { continue; } ?>
				<li><b data-count><?php echo esc_html( ip_opt( "stat_{$i}_num" ) ); ?></b><span><?php echo esc_html( ip_opt( "stat_{$i}_label" ) ); ?></span></li>
			<?php endfor; ?>
		</ul>
	</div>
</section>

<?php get_footer(); ?>
