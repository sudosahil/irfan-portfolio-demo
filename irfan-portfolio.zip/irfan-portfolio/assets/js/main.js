( function () {
	const reduced = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

	// Menu overlay
	const toggle = document.querySelector( '.menu-toggle' );
	const overlay = document.getElementById( 'menu-overlay' );
	function setMenu( open ) {
		toggle.setAttribute( 'aria-expanded', String( open ) );
		overlay.hidden = ! open;
		document.body.classList.toggle( 'menu-open', open );
	}
	if ( toggle && overlay ) {
		toggle.addEventListener( 'click', () => setMenu( toggle.getAttribute( 'aria-expanded' ) !== 'true' ) );
		overlay.addEventListener( 'click', ( e ) => { if ( e.target.closest( 'a' ) ) setMenu( false ); } );
		document.addEventListener( 'keydown', ( e ) => { if ( e.key === 'Escape' ) setMenu( false ); } );
	}

	// Today's date in the header card
	const date = document.querySelector( '[data-date]' );
	if ( date ) date.textContent = new Date().toLocaleDateString( 'en-IN', { weekday: 'long', month: 'short', day: 'numeric' } );

	// Mouse spotlight on the hero
	const hero = document.querySelector( '[data-spotlight]' );
	if ( hero && ! reduced ) {
		hero.addEventListener( 'pointermove', ( e ) => {
			const r = hero.getBoundingClientRect();
			hero.style.setProperty( '--mx', ( e.clientX - r.left ) + 'px' );
			hero.style.setProperty( '--my', ( e.clientY - r.top ) + 'px' );
		} );
	}

	// Count-up numbers ("90+", "$5M+", "₹3Cr")
	function countUp( el ) {
		const m = el.textContent.trim().match( /^(\D*)(\d+(?:\.\d+)?)(.*)$/ );
		if ( ! m || reduced ) return;
		const [ , pre, num, post ] = m;
		const end = parseFloat( num );
		const dec = ( num.split( '.' )[ 1 ] || '' ).length;
		const start = performance.now();
		const dur = 1400;
		( function tick( now ) {
			const t = Math.min( 1, ( now - start ) / dur );
			const eased = 1 - Math.pow( 1 - t, 3 );
			el.textContent = pre + ( end * eased ).toFixed( dec ) + post;
			if ( t < 1 ) requestAnimationFrame( tick );
		} )( start );
	}
	const counters = document.querySelectorAll( '[data-count]' );

	// Scroll reveal. On desktop the panel is the scroller, so observe inside it.
	const items = document.querySelectorAll( '.reveal' );
	const panel = document.querySelector( '.panel' );
	const root = panel && panel.scrollHeight > panel.clientHeight + 2 && getComputedStyle( panel ).overflowY === 'auto' ? panel : null;
	if ( 'IntersectionObserver' in window && ! reduced ) {
		if ( items.length ) document.documentElement.classList.add( 'js-reveal' );
		const io = new IntersectionObserver( ( entries ) => {
			entries.forEach( ( entry ) => {
				if ( ! entry.isIntersecting ) return;
				entry.target.classList.add( 'in' );
				if ( entry.target.hasAttribute( 'data-count' ) ) countUp( entry.target );
				io.unobserve( entry.target );
			} );
		}, { root, threshold: 0.12 } );
		items.forEach( ( el, i ) => { el.style.transitionDelay = ( i % 3 ) * 80 + 'ms'; io.observe( el ); } );
		counters.forEach( ( el ) => io.observe( el ) );
	}

	// Prevent double submits on the contact form.
	const form = document.querySelector( '.form' );
	if ( form ) {
		form.addEventListener( 'submit', () => {
			const btn = form.querySelector( 'button[type=submit]' );
			if ( btn && form.checkValidity() ) { btn.disabled = true; btn.textContent = 'Sending…'; }
		} );
	}
} )();
